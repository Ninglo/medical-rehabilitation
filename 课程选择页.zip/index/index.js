const app = getApp()

Page({
  data: {
    oneSentence:'查看更多',
    listLen:1,
    navbartxt: ['课程类型1','2','3','4'],
    course:[
      {
        courseTitle:'康复课程xxx',
        courseIntdc:'一段介绍 | 时间',
        url:'https://media.w3.org/2010/05/sintel/trailer.mp4'
      },
      {
        courseTitle: '康复课程xxx',
        courseIntdc: '一段介绍 | 时间',
        url:'http://www.w3school.com.cn/example/html5/mov_bbb.mp4'
      },
      {
        courseTitle: '康复课程xxx',
        courseIntdc: '一段介绍 | 时间',
        url:'https://www.w3schools.com/html/movie.mp4'
      },
      {
        courseTitle: '康复课程xxx',
        courseIntdc: '一段介绍 | 时间',
        url:'http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4'
      },
      {
        courseTitle: '康复课程xxx',
        courseIntdc: '一段介绍 | 时间',
        url:'http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8'
      }
    ],
    
  },
  viewMore: function () {
    var listLen = this.data.listLen + 1;
    console.log(listLen);
    this.setData(
      {
        listLen: listLen
      }
    )
  }


  
})
